const path = require("path");
const express = require("express");
const Database = require("better-sqlite3");

const app = express();

// Папка с фронтендом (HTML-шаблон и CSS) лежит рядом с backend
const FRONTEND = path.join(__dirname, "..", "frontend");

// База хранится в файле savings.db рядом с server.js (в папке backend)
const db = new Database(path.join(__dirname, "savings.db"));

// Создаём таблицу при первом запуске
db.exec(`
  CREATE TABLE IF NOT EXISTS savings (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,  -- ID
    name   TEXT NOT NULL,                      -- имя накопления
    saved  REAL NOT NULL DEFAULT 0,            -- накопленная сумма
    target REAL NOT NULL                       -- сумма накопления (цель)
  )
`);

app.set("view engine", "ejs");
app.set("views", FRONTEND);
app.use(express.urlencoded({ extended: false })); // чтобы читать данные форм

// Отдаём браузеру только файл стилей (шаблон index.ejs остаётся закрытым)
app.get("/style.css", (req, res) => res.sendFile(path.join(FRONTEND, "style.css")));

// Превращает строку в число (понимает и запятую). При ошибке вернёт null.
function parseAmount(text) {
  const s = String(text ?? "").replace(/\s/g, "").replace(",", ".");
  if (s === "") return null;
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
}

function showPage(res, error = null) {
  const rows = db
    .prepare("SELECT id, name, saved, target FROM savings ORDER BY id DESC")
    .all();

  const items = rows.map((r) => ({
    ...r,
    percent: r.target > 0 ? Math.min(100, (r.saved / r.target) * 100) : 0,
  }));

  res.render("index", {
    items,
    error,
  });
}

app.get("/", (req, res) => showPage(res));

app.post("/add", (req, res) => {
  const name = String(req.body.name ?? "").trim();
  const target = parseAmount(req.body.target);
  const savedText = String(req.body.saved ?? "").trim();
  const saved = savedText ? parseAmount(savedText) : 0;

  if (!name || target === null || target <= 0 || saved === null || saved < 0) {
    return showPage(res, "Проверьте данные: нужна сумма больше нуля, только числа.");
  }

  // ? защищают от SQL-инъекций
  db.prepare("INSERT INTO savings (name, saved, target) VALUES (?, ?, ?)").run(
    name,
    saved,
    target
  );
  res.redirect("/");
});

app.post("/change/:id", (req, res) => {
  const id = Number(req.params.id);
  let amount = parseAmount(req.body.amount);
  if (amount === null || amount <= 0) {
    return showPage(res, "Введите сумму накопления.");
  }

  const item = db.prepare("SELECT name, saved FROM savings WHERE id = ?").get(id);
  if (!item) return res.redirect("/");

  if (req.body.action === "sub") {
    // Сравниваем в копейках, чтобы не мешали ошибки округления дробных чисел
    if (Math.round(amount * 100) > Math.round(item.saved * 100)) {
      return showPage(
        res,
        `Нельзя снять ${amount.toFixed(2)} ₽ с накопления «${item.name}», так как накоплено только ${item.saved.toFixed(2)} ₽.`
      );
    }
    amount = -amount;
  }

  // ROUND(..., 2) держит сумму с двумя знаками после запятой
  db.prepare("UPDATE savings SET saved = ROUND(saved + ?, 2) WHERE id = ?").run(amount, id);
  res.redirect("/");
});

app.post("/delete/:id", (req, res) => {
  db.prepare("DELETE FROM savings WHERE id = ?").run(Number(req.params.id));
  res.redirect("/");
});

app.listen(3000, () => console.log("Сайт запущен: http://localhost:3000"));